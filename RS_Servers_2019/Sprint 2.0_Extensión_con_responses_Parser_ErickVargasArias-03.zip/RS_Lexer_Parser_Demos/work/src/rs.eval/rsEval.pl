/*
EIF400 loriacarlos@gmail.com
II-2019
*/
:- module(rsEval, [eval/3]).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Test %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% to do folks!

eval(User, Msg, Reply) :-
  throw('Eval not implemented').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%